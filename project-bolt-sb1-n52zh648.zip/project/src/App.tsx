import { useEffect, useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { Landing } from './pages/Landing';
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { Dashboard } from './pages/Dashboard';
import { Analyze } from './pages/Analyze';
import { Reports } from './pages/Reports';
import { Roles } from './pages/Roles';
import { Settings } from './pages/Settings';

function Router() {
  const { user, loading } = useAuth();
  const [currentPath, setCurrentPath] = useState(window.location.pathname);

  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname);
    };

    window.addEventListener('popstate', handlePopState);

    const originalPushState = window.history.pushState;
    window.history.pushState = function (...args) {
      originalPushState.apply(window.history, args);
      setCurrentPath(window.location.pathname);
    };

    return () => {
      window.removeEventListener('popstate', handlePopState);
      window.history.pushState = originalPushState;
    };
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-400">Loading...</p>
        </div>
      </div>
    );
  }

  const publicRoutes = ['/', '/login', '/register'];
  const isPublicRoute = publicRoutes.includes(currentPath);

  if (!user && !isPublicRoute) {
    window.location.href = '/login';
    return null;
  }

  if (user && (currentPath === '/login' || currentPath === '/register')) {
    window.location.href = '/dashboard';
    return null;
  }

  switch (currentPath) {
    case '/':
      return <Landing />;
    case '/login':
      return <Login />;
    case '/register':
      return <Register />;
    case '/dashboard':
      return <Dashboard />;
    case '/analyze':
      return <Analyze />;
    case '/reports':
      return <Reports />;
    case '/roles':
      return <Roles />;
    case '/settings':
      return <Settings />;
    default:
      return <Landing />;
  }
}

function App() {
  return (
    <AuthProvider>
      <Router />
    </AuthProvider>
  );
}

export default App;
