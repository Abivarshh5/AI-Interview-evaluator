import { useEffect, useState } from 'react';
import { Plus, Edit2, Trash2, Briefcase } from 'lucide-react';
import { Layout } from '../components/Layout';
import { Card } from '../components/Card';
import { Button } from '../components/Button';
import { Input } from '../components/Input';
import { supabase, EvaluationRole } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

export function Roles() {
  const { user } = useAuth();
  const [roles, setRoles] = useState<EvaluationRole[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingRole, setEditingRole] = useState<EvaluationRole | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    icon: 'briefcase',
    color: '#6366f1',
  });

  useEffect(() => {
    loadRoles();
  }, []);

  const loadRoles = async () => {
    try {
      const { data, error } = await supabase
        .from('evaluation_roles')
        .select('*')
        .order('is_default', { ascending: false });

      if (error) throw error;
      setRoles(data || []);
    } catch (error) {
      console.error('Error loading roles:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    try {
      if (editingRole) {
        const { error } = await supabase
          .from('evaluation_roles')
          .update({
            title: formData.title,
            description: formData.description,
            icon: formData.icon,
            color: formData.color,
          })
          .eq('id', editingRole.id);

        if (error) throw error;
      } else {
        const { error } = await supabase.from('evaluation_roles').insert({
          user_id: user.id,
          title: formData.title,
          description: formData.description,
          icon: formData.icon,
          color: formData.color,
          criteria: [
            { name: 'Communication', description: 'Clear and effective communication', weight: 25 },
            { name: 'Problem Solving', description: 'Ability to resolve issues', weight: 25 },
            { name: 'Professionalism', description: 'Professional conduct and demeanor', weight: 25 },
            { name: 'Customer Service', description: 'Quality of service provided', weight: 25 },
          ],
        });

        if (error) throw error;
      }

      loadRoles();
      setShowModal(false);
      setEditingRole(null);
      setFormData({ title: '', description: '', icon: 'briefcase', color: '#6366f1' });
    } catch (error) {
      console.error('Error saving role:', error);
    }
  };

  const handleEdit = (role: EvaluationRole) => {
    setEditingRole(role);
    setFormData({
      title: role.title,
      description: role.description,
      icon: role.icon,
      color: role.color,
    });
    setShowModal(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this role?')) return;

    try {
      const { error } = await supabase.from('evaluation_roles').delete().eq('id', id);
      if (error) throw error;
      setRoles(roles.filter((r) => r.id !== id));
    } catch (error) {
      console.error('Error deleting role:', error);
    }
  };

  const iconOptions = ['briefcase', 'headset', 'trending-up', 'wrench', 'users', 'phone'];

  return (
    <Layout currentPage="/roles">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8 flex items-center justify-between flex-wrap gap-4">
          <div>
            <h2 className="text-3xl font-bold text-white mb-2">Evaluation Roles</h2>
            <p className="text-gray-400">Create and manage custom evaluation criteria</p>
          </div>
          <Button
            onClick={() => {
              setEditingRole(null);
              setFormData({ title: '', description: '', icon: 'briefcase', color: '#6366f1' });
              setShowModal(true);
            }}
          >
            <Plus className="w-4 h-4" />
            Create New Role
          </Button>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse">
                <Card>
                  <div className="h-40 bg-slate-700/50 rounded-lg" />
                </Card>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {roles.map((role) => (
              <Card key={role.id} hover>
                <div className="mb-4">
                  <div
                    className="w-12 h-12 rounded-lg flex items-center justify-center mb-3"
                    style={{ background: `linear-gradient(135deg, ${role.color}, ${role.color}dd)` }}
                  >
                    <Briefcase className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-1">{role.title}</h3>
                  {role.is_default && (
                    <span className="inline-block px-2 py-1 text-xs bg-indigo-500/20 text-indigo-400 rounded">
                      Default
                    </span>
                  )}
                </div>

                <p className="text-gray-400 text-sm mb-4 line-clamp-2">{role.description}</p>

                <div className="flex items-center justify-between mb-4">
                  <span className="text-gray-400 text-sm">Usage</span>
                  <span className="text-white font-semibold">{role.usage_count} reports</span>
                </div>

                <div className="flex gap-2">
                  {!role.is_default && (
                    <>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="flex-1"
                        onClick={() => handleEdit(role)}
                      >
                        <Edit2 className="w-4 h-4" />
                        Edit
                      </Button>
                      <button
                        onClick={() => handleDelete(role.id)}
                        className="p-2 text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg transition-all"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </>
                  )}
                  {role.is_default && (
                    <Button variant="ghost" size="sm" className="w-full">
                      Use for Analysis
                    </Button>
                  )}
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 rounded-2xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-gray-700">
            <h3 className="text-2xl font-bold text-white mb-6">
              {editingRole ? 'Edit Role' : 'Create New Role'}
            </h3>

            <form onSubmit={handleSubmit} className="space-y-4">
              <Input
                label="Role Title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="e.g., Customer Service Rep"
                required
              />

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Description
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Describe the role and evaluation criteria..."
                  className="w-full px-4 py-3 bg-slate-800/50 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 resize-none"
                  rows={4}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Color</label>
                <input
                  type="color"
                  value={formData.color}
                  onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                  className="w-full h-12 rounded-lg cursor-pointer"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <Button type="submit" className="flex-1">
                  {editingRole ? 'Update Role' : 'Create Role'}
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() => {
                    setShowModal(false);
                    setEditingRole(null);
                  }}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </Layout>
  );
}
