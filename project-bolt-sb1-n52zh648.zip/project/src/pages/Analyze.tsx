import { useState, useEffect } from 'react';
import { Upload, FileAudio, FileText, Loader2, CheckCircle } from 'lucide-react';
import { Layout } from '../components/Layout';
import { Card } from '../components/Card';
import { Button } from '../components/Button';
import { supabase, EvaluationRole } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

export function Analyze() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'upload' | 'text'>('upload');
  const [file, setFile] = useState<File | null>(null);
  const [textInput, setTextInput] = useState('');
  const [selectedRole, setSelectedRole] = useState('');
  const [roles, setRoles] = useState<EvaluationRole[]>([]);
  const [processing, setProcessing] = useState(false);
  const [processingStage, setProcessingStage] = useState('');
  const [result, setResult] = useState<any>(null);
  const [dragActive, setDragActive] = useState(false);

  useEffect(() => {
    loadRoles();
  }, []);

  const loadRoles = async () => {
    const { data, error } = await supabase
      .from('evaluation_roles')
      .select('*')
      .order('is_default', { ascending: false });

    if (error) {
      console.error('Error loading roles:', error);
    } else {
      setRoles(data || []);
      if (data && data.length > 0) {
        setSelectedRole(data[0].id);
      }
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const simulateProcessing = async () => {
    setProcessing(true);

    setProcessingStage('Transcribing audio...');
    await new Promise((resolve) => setTimeout(resolve, 2000));

    setProcessingStage('Generating summary...');
    await new Promise((resolve) => setTimeout(resolve, 1500));

    setProcessingStage('Evaluating performance...');
    await new Promise((resolve) => setTimeout(resolve, 1500));

    const role = roles.find((r) => r.id === selectedRole);
    const mockScore = Math.floor(Math.random() * 30) + 70;

    const mockTranscript =
      activeTab === 'text'
        ? textInput
        : "Hello, thank you for calling customer service. My name is Sarah, and I'll be happy to assist you today. I understand you're having an issue with your recent order. Could you please provide me with your order number? Thank you. I can see your order here. I apologize for the inconvenience you've experienced. Let me look into this right away and find the best solution for you. I see the issue now, and I can definitely help resolve this. Would you prefer a replacement or a full refund? Perfect, I'll process that refund for you right now. You should see it in your account within 3-5 business days. Is there anything else I can help you with today? Thank you for your patience and understanding. Have a wonderful day!";

    const mockSummary =
      "Customer service representative handled an order issue professionally. Greeted the customer warmly, actively listened to the problem, showed empathy, and efficiently resolved the issue by offering a refund. Confirmed customer satisfaction before closing the call.";

    const mockEvaluation = role?.criteria.map((criterion: any) => ({
      name: criterion.name,
      score: Math.floor(Math.random() * 30) + 70,
      feedback: `Strong performance in ${criterion.name.toLowerCase()}. Demonstrated good practices throughout the interaction.`,
    })) || [];

    setResult({
      transcript: mockTranscript,
      summary: mockSummary,
      score: mockScore,
      evaluation: mockEvaluation,
      role: role?.title || 'Unknown Role',
    });

    if (user) {
      await supabase.from('reports').insert({
        user_id: user.id,
        role_id: selectedRole,
        title: file?.name || `Text Analysis - ${new Date().toLocaleDateString()}`,
        file_type: activeTab === 'upload' ? 'audio' : 'text',
        transcript: mockTranscript,
        summary: mockSummary,
        evaluation_score: mockScore,
        evaluation_details: { criteria: mockEvaluation },
        processing_status: 'completed',
        duration_seconds: activeTab === 'upload' ? Math.floor(Math.random() * 600) + 120 : null,
      });
    }

    setProcessing(false);
  };

  const handleProcess = () => {
    if ((activeTab === 'upload' && !file) || (activeTab === 'text' && !textInput.trim())) {
      return;
    }
    if (!selectedRole) {
      return;
    }
    simulateProcessing();
  };

  const handleReset = () => {
    setFile(null);
    setTextInput('');
    setResult(null);
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-emerald-400';
    if (score >= 60) return 'text-amber-400';
    return 'text-red-400';
  };

  if (processing) {
    return (
      <Layout currentPage="/analyze">
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-slate-800 rounded-2xl p-8 max-w-md w-full mx-4 border border-gray-700">
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6 animate-pulse">
                <Loader2 className="w-10 h-10 text-white animate-spin" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">Processing Your Audio</h3>
              <p className="text-gray-400 mb-6">{processingStage}</p>
              <div className="w-full bg-slate-700 rounded-full h-2 overflow-hidden">
                <div className="bg-gradient-to-r from-indigo-600 to-purple-600 h-full rounded-full animate-pulse" style={{ width: '70%' }} />
              </div>
              <p className="text-sm text-gray-500 mt-4">This may take a few minutes...</p>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  if (result) {
    return (
      <Layout currentPage="/analyze">
        <div className="max-w-7xl mx-auto">
          <div className="mb-6 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-emerald-600 to-teal-600 rounded-lg flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white">Analysis Complete!</h2>
                <p className="text-gray-400">Your results are ready</p>
              </div>
            </div>
            <div className="flex gap-3">
              <Button variant="ghost" onClick={handleReset}>
                New Analysis
              </Button>
              <Button onClick={() => window.location.href = '/reports'}>
                View All Reports
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <Card>
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-indigo-400" />
                  Transcript
                </h3>
                <div className="bg-slate-900/50 rounded-lg p-4 max-h-64 overflow-y-auto">
                  <p className="text-gray-300 leading-relaxed">{result.transcript}</p>
                </div>
                <Button variant="ghost" size="sm" className="mt-3">
                  Copy Transcript
                </Button>
              </Card>

              <Card>
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-teal-400" />
                  Summary
                </h3>
                <div className="bg-slate-900/50 rounded-lg p-4">
                  <p className="text-gray-300 leading-relaxed">{result.summary}</p>
                </div>
                <Button variant="ghost" size="sm" className="mt-3">
                  Copy Summary
                </Button>
              </Card>
            </div>

            <div className="space-y-6">
              <Card>
                <h3 className="text-lg font-semibold text-white mb-4">Overall Score</h3>
                <div className="text-center mb-6">
                  <div className={`text-6xl font-bold ${getScoreColor(result.score)} mb-2`}>
                    {result.score}
                  </div>
                  <p className="text-gray-400">out of 100</p>
                  <p className="text-sm text-gray-500 mt-2">{result.role}</p>
                </div>
                <div className="w-full bg-slate-700 rounded-full h-3 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-indigo-600 to-purple-600 h-full rounded-full transition-all duration-1000"
                    style={{ width: `${result.score}%` }}
                  />
                </div>
              </Card>

              <Card>
                <h3 className="text-lg font-semibold text-white mb-4">Evaluation Breakdown</h3>
                <div className="space-y-4">
                  {result.evaluation.map((item: any, index: number) => (
                    <div key={index}>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm text-gray-300">{item.name}</span>
                        <span className={`text-sm font-semibold ${getScoreColor(item.score)}`}>
                          {item.score}
                        </span>
                      </div>
                      <div className="w-full bg-slate-700 rounded-full h-2 overflow-hidden">
                        <div
                          className="bg-gradient-to-r from-indigo-600 to-purple-600 h-full rounded-full"
                          style={{ width: `${item.score}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout currentPage="/analyze">
      <div className="max-w-5xl mx-auto">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">New Analysis</h2>
          <p className="text-gray-400">Upload audio/video or paste text to get started</p>
        </div>

        <div className="flex gap-4 mb-6">
          <button
            onClick={() => setActiveTab('upload')}
            className={`flex-1 py-3 px-6 rounded-lg font-medium transition-all ${
              activeTab === 'upload'
                ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg'
                : 'bg-slate-800/50 text-gray-400 hover:bg-slate-800'
            }`}
          >
            <FileAudio className="w-5 h-5 inline mr-2" />
            Upload Audio/Video
          </button>
          <button
            onClick={() => setActiveTab('text')}
            className={`flex-1 py-3 px-6 rounded-lg font-medium transition-all ${
              activeTab === 'text'
                ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg'
                : 'bg-slate-800/50 text-gray-400 hover:bg-slate-800'
            }`}
          >
            <FileText className="w-5 h-5 inline mr-2" />
            Direct Text Input
          </button>
        </div>

        {activeTab === 'upload' ? (
          <Card>
            <div
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-xl p-12 text-center transition-all ${
                dragActive
                  ? 'border-indigo-500 bg-indigo-500/10'
                  : 'border-gray-600 hover:border-gray-500'
              }`}
            >
              <input
                type="file"
                id="file-upload"
                accept="audio/*,video/*"
                onChange={handleFileChange}
                className="hidden"
              />
              <label htmlFor="file-upload" className="cursor-pointer">
                <Upload className="w-16 h-16 text-gray-500 mx-auto mb-4" />
                <p className="text-xl text-white mb-2">
                  {file ? file.name : 'Drop your file here or click to browse'}
                </p>
                <p className="text-gray-400 text-sm mb-4">
                  Supports WAV, MP3, MP4, and more
                </p>
                <div className="inline-block px-4 py-2 bg-slate-800 rounded-lg text-gray-300 text-sm">
                  Max size: 100MB
                </div>
              </label>
            </div>

            {file && (
              <div className="mt-6 p-4 bg-slate-800/30 rounded-lg flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <FileAudio className="w-8 h-8 text-indigo-400" />
                  <div>
                    <p className="text-white font-medium">{file.name}</p>
                    <p className="text-gray-400 text-sm">
                      {(file.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setFile(null)}
                  className="text-red-400 hover:text-red-300"
                >
                  Remove
                </button>
              </div>
            )}
          </Card>
        ) : (
          <Card>
            <textarea
              value={textInput}
              onChange={(e) => setTextInput(e.target.value)}
              placeholder="Paste your transcript here..."
              className="w-full h-64 bg-slate-900/50 border border-gray-700 rounded-lg p-4 text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 resize-none"
            />
            <div className="mt-2 text-right text-sm text-gray-500">
              {textInput.length} characters
            </div>
          </Card>
        )}

        <div className="mt-6 grid md:grid-cols-2 gap-6">
          <Card>
            <label className="block text-sm font-medium text-gray-300 mb-3">
              Evaluation Role
            </label>
            <select
              value={selectedRole}
              onChange={(e) => setSelectedRole(e.target.value)}
              className="w-full px-4 py-3 bg-slate-900/50 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
            >
              {roles.map((role) => (
                <option key={role.id} value={role.id}>
                  {role.title}
                </option>
              ))}
            </select>
            <a
              href="/roles"
              className="inline-block mt-3 text-sm text-indigo-400 hover:text-indigo-300"
            >
              + Create New Role
            </a>
          </Card>

          <Card>
            <div className="h-full flex flex-col justify-between">
              <div>
                <p className="text-sm text-gray-400 mb-2">Ready to analyze?</p>
                <p className="text-xs text-gray-500">
                  Select a role and {activeTab === 'upload' ? 'upload a file' : 'enter text'} to begin
                </p>
              </div>
              <Button
                onClick={handleProcess}
                disabled={
                  !selectedRole ||
                  (activeTab === 'upload' ? !file : !textInput.trim())
                }
                className="w-full mt-4"
              >
                Start Processing
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
