import { useEffect, useState } from 'react';
import { FileText, Clock, Users, TrendingUp, Plus } from 'lucide-react';
import { Layout } from '../components/Layout';
import { Card } from '../components/Card';
import { Button } from '../components/Button';
import { useAuth } from '../contexts/AuthContext';
import { supabase, Report } from '../lib/supabase';

export function Dashboard() {
  const { profile } = useAuth();
  const [reports, setReports] = useState<Report[]>([]);
  const [stats, setStats] = useState({
    totalReports: 0,
    hoursProcessed: 0,
    rolesCreated: 0,
    avgScore: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const { data: reportsData, error: reportsError } = await supabase
        .from('reports')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(5);

      if (reportsError) throw reportsError;

      const { count: totalCount } = await supabase
        .from('reports')
        .select('*', { count: 'exact', head: true });

      const { count: rolesCount } = await supabase
        .from('evaluation_roles')
        .select('*', { count: 'exact', head: true });

      const { data: allReports } = await supabase
        .from('reports')
        .select('duration_seconds, evaluation_score');

      const totalSeconds = allReports?.reduce((sum, r) => sum + (r.duration_seconds || 0), 0) || 0;
      const avgScore = allReports?.length
        ? allReports.reduce((sum, r) => sum + Number(r.evaluation_score), 0) / allReports.length
        : 0;

      setReports(reportsData || []);
      setStats({
        totalReports: totalCount || 0,
        hoursProcessed: Math.round((totalSeconds / 3600) * 10) / 10,
        rolesCreated: rolesCount || 0,
        avgScore: Math.round(avgScore * 10) / 10,
      });
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-emerald-400';
    if (score >= 60) return 'text-amber-400';
    return 'text-red-400';
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  return (
    <Layout currentPage="/dashboard">
      <div className="max-w-7xl mx-auto space-y-8">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">
            Welcome back, {profile?.full_name?.split(' ')[0] || 'there'}!
          </h2>
          <p className="text-gray-400">
            Here's an overview of your audio analysis activity
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              label: 'Total Reports',
              value: stats.totalReports,
              icon: FileText,
              color: 'from-indigo-600 to-purple-600',
            },
            {
              label: 'Hours Processed',
              value: stats.hoursProcessed,
              icon: Clock,
              color: 'from-teal-600 to-cyan-600',
            },
            {
              label: 'Roles Created',
              value: stats.rolesCreated,
              icon: Users,
              color: 'from-amber-600 to-orange-600',
            },
            {
              label: 'Avg. Score',
              value: stats.avgScore,
              icon: TrendingUp,
              color: 'from-emerald-600 to-teal-600',
            },
          ].map((stat, index) => (
            <Card key={index}>
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-gray-400 text-sm mb-1">{stat.label}</p>
                  <p className="text-3xl font-bold text-white">{stat.value}</p>
                </div>
                <div className={`w-12 h-12 bg-gradient-to-br ${stat.color} rounded-lg flex items-center justify-center`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
              </div>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold text-white">Recent Reports</h3>
                <a href="/reports" className="text-indigo-400 hover:text-indigo-300 text-sm font-medium">
                  View All
                </a>
              </div>

              {loading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="animate-pulse">
                      <div className="h-16 bg-slate-700/50 rounded-lg" />
                    </div>
                  ))}
                </div>
              ) : reports.length === 0 ? (
                <div className="text-center py-12">
                  <FileText className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400 mb-4">No reports yet</p>
                  <p className="text-gray-500 text-sm mb-6">
                    Upload your first audio file to get started!
                  </p>
                  <Button onClick={() => window.location.href = '/analyze'}>
                    <Plus className="w-4 h-4" />
                    New Analysis
                  </Button>
                </div>
              ) : (
                <div className="space-y-3">
                  {reports.map((report) => (
                    <div
                      key={report.id}
                      className="flex items-center justify-between p-4 bg-slate-800/30 hover:bg-slate-800/50 rounded-lg transition-all cursor-pointer"
                      onClick={() => window.location.href = `/reports?id=${report.id}`}
                    >
                      <div className="flex items-center gap-4 flex-1">
                        <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center">
                          <FileText className="w-5 h-5 text-white" />
                        </div>
                        <div className="flex-1">
                          <p className="text-white font-medium">{report.title}</p>
                          <p className="text-gray-400 text-sm">{formatDate(report.created_at)}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={`text-2xl font-bold ${getScoreColor(Number(report.evaluation_score))}`}>
                          {Math.round(Number(report.evaluation_score))}
                        </p>
                        <p className="text-gray-500 text-xs">Score</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <h3 className="text-xl font-semibold text-white mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <Button
                  className="w-full justify-start"
                  onClick={() => window.location.href = '/analyze'}
                >
                  <Plus className="w-4 h-4" />
                  New Analysis
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start"
                  onClick={() => window.location.href = '/roles'}
                >
                  <Users className="w-4 h-4" />
                  Manage Roles
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start"
                  onClick={() => window.location.href = '/reports'}
                >
                  <FileText className="w-4 h-4" />
                  View Reports
                </Button>
              </div>
            </Card>

            <Card>
              <h3 className="text-lg font-semibold text-white mb-3">Tips & Tricks</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li className="flex gap-2">
                  <span className="text-indigo-400">•</span>
                  <span>Use custom roles for specific evaluation criteria</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-indigo-400">•</span>
                  <span>Higher quality audio leads to better transcription accuracy</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-indigo-400">•</span>
                  <span>Review and compare reports to track improvements</span>
                </li>
              </ul>
            </Card>
          </div>
        </div>
      </div>

      <button
        onClick={() => window.location.href = '/analyze'}
        className="fixed bottom-8 right-8 w-14 h-14 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-full shadow-2xl hover:shadow-indigo-500/50 hover:scale-110 transition-all flex items-center justify-center group"
      >
        <Plus className="w-6 h-6 text-white" />
      </button>
    </Layout>
  );
}
