import { Mic, FileText, Target, Shield, BarChart3, Zap } from 'lucide-react';
import { Button } from '../components/Button';
import { Card } from '../components/Card';

export function Landing() {
  const scrollToFeatures = () => {
    document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950">
      <nav className="fixed top-0 w-full bg-slate-900/80 backdrop-blur-md border-b border-gray-800 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center">
              <Mic className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">
              AudioInsight
            </span>
          </div>
          <div className="flex items-center gap-4">
            <a href="/login" className="text-gray-300 hover:text-white transition-colors">
              Sign In
            </a>
            <Button onClick={() => window.location.href = '/register'}>
              Get Started
            </Button>
          </div>
        </div>
      </nav>

      <section className="pt-32 pb-20 px-6">
        <div className="max-w-6xl mx-auto text-center">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-indigo-600/20 to-purple-600/20 blur-3xl -z-10" />
            <h1 className="text-6xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-white via-indigo-200 to-purple-200 bg-clip-text text-transparent leading-tight">
              Transform Audio into
              <br />
              Actionable Insights
            </h1>
          </div>

          <p className="text-xl text-gray-400 mb-8 max-w-2xl mx-auto">
            AI-powered transcription, summarization, and role-based evaluation
            to unlock the full potential of your audio content
          </p>

          <div className="flex items-center justify-center gap-4">
            <Button size="lg" onClick={() => window.location.href = '/register'}>
              Get Started Free
            </Button>
            <Button size="lg" variant="ghost" onClick={scrollToFeatures}>
              Learn More
            </Button>
          </div>

          <div className="mt-16 grid grid-cols-3 gap-8 max-w-3xl mx-auto">
            {[
              { label: 'Hours Processed', value: '10,000+' },
              { label: 'Active Users', value: '2,500+' },
              { label: 'Accuracy Rate', value: '99.2%' },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-3xl font-bold text-white mb-1">{stat.value}</div>
                <div className="text-sm text-gray-500">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="features" className="py-20 px-6 bg-gradient-to-b from-transparent to-slate-900/50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Powerful Features for Every Need
            </h2>
            <p className="text-gray-400 text-lg">
              Everything you need to analyze and evaluate audio content at scale
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: Mic,
                title: 'Multi-Format Support',
                description: 'Upload WAV, MP3, MP4, and more. We handle all major audio and video formats.',
                color: 'from-indigo-600 to-purple-600',
              },
              {
                icon: Zap,
                title: 'AI-Powered Transcription',
                description: 'State-of-the-art speech recognition with 99%+ accuracy across multiple languages.',
                color: 'from-purple-600 to-pink-600',
              },
              {
                icon: FileText,
                title: 'Smart Summarization',
                description: 'Get concise summaries that capture the key points and essential information.',
                color: 'from-teal-600 to-cyan-600',
              },
              {
                icon: Target,
                title: 'Role-Based Evaluation',
                description: 'Custom evaluation criteria for different roles like sales, support, and more.',
                color: 'from-amber-600 to-orange-600',
              },
              {
                icon: BarChart3,
                title: 'Detailed Analytics',
                description: 'Comprehensive insights and scoring based on your specific evaluation criteria.',
                color: 'from-emerald-600 to-teal-600',
              },
              {
                icon: Shield,
                title: 'Secure & Private',
                description: 'Enterprise-grade security with end-to-end encryption and data privacy.',
                color: 'from-blue-600 to-indigo-600',
              },
            ].map((feature, index) => (
              <Card key={index} hover>
                <div className={`w-12 h-12 bg-gradient-to-br ${feature.color} rounded-lg flex items-center justify-center mb-4`}>
                  <feature.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">{feature.title}</h3>
                <p className="text-gray-400">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              How It Works
            </h2>
            <p className="text-gray-400 text-lg">
              Three simple steps to transform your audio into insights
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: '01',
                title: 'Upload & Select',
                description: 'Upload your audio/video file or paste a transcript. Choose an evaluation role.',
              },
              {
                step: '02',
                title: 'AI Processing',
                description: 'Our AI transcribes, summarizes, and analyzes your content in minutes.',
              },
              {
                step: '03',
                title: 'Get Insights',
                description: 'Receive detailed reports with scores, summaries, and actionable feedback.',
              },
            ].map((item, index) => (
              <div key={index} className="relative">
                {index < 2 && (
                  <div className="hidden md:block absolute top-12 left-full w-full h-0.5 bg-gradient-to-r from-indigo-600 to-transparent" />
                )}
                <div className="text-6xl font-bold bg-gradient-to-br from-indigo-600 to-purple-600 bg-clip-text text-transparent mb-4">
                  {item.step}
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">{item.title}</h3>
                <p className="text-gray-400">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-6 bg-gradient-to-r from-indigo-950/50 to-purple-950/50">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-gray-400 mb-8">
            Join thousands of professionals who are already transforming their audio content
          </p>
          <Button size="lg" onClick={() => window.location.href = '/register'}>
            Start Free Trial
          </Button>
        </div>
      </section>

      <footer className="py-12 px-6 border-t border-gray-800">
        <div className="max-w-6xl mx-auto text-center text-gray-500">
          <p>&copy; 2024 AudioInsight. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
