import { useState } from 'react';
import { User, Lock, Bell, Palette } from 'lucide-react';
import { Layout } from '../components/Layout';
import { Card } from '../components/Card';
import { Button } from '../components/Button';
import { Input } from '../components/Input';
import { useAuth } from '../contexts/AuthContext';

export function Settings() {
  const { profile, updateProfile } = useAuth();
  const [activeTab, setActiveTab] = useState('profile');
  const [formData, setFormData] = useState({
    full_name: profile?.full_name || '',
    bio: profile?.bio || '',
  });
  const [saved, setSaved] = useState(false);

  const tabs = [
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'security', label: 'Security', icon: Lock },
    { id: 'preferences', label: 'Preferences', icon: Palette },
    { id: 'notifications', label: 'Notifications', icon: Bell },
  ];

  const handleSave = async () => {
    await updateProfile(formData);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <Layout currentPage="/settings">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Settings</h2>
          <p className="text-gray-400">Manage your account settings and preferences</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <Card className="lg:col-span-1 h-fit">
            <nav className="space-y-2">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                    activeTab === tab.id
                      ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white'
                      : 'text-gray-400 hover:text-white hover:bg-slate-800/50'
                  }`}
                >
                  <tab.icon className="w-5 h-5" />
                  <span className="font-medium">{tab.label}</span>
                </button>
              ))}
            </nav>
          </Card>

          <div className="lg:col-span-3">
            {activeTab === 'profile' && (
              <Card>
                <h3 className="text-xl font-semibold text-white mb-6">Profile Information</h3>
                <div className="space-y-4">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-20 h-20 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-full flex items-center justify-center text-2xl text-white font-bold">
                      {profile?.full_name?.[0]?.toUpperCase() || 'U'}
                    </div>
                    <Button variant="ghost" size="sm">
                      Change Avatar
                    </Button>
                  </div>

                  <Input
                    label="Full Name"
                    value={formData.full_name}
                    onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                  />

                  <Input label="Email" value={profile?.email || ''} disabled />

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Bio</label>
                    <textarea
                      value={formData.bio}
                      onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                      placeholder="Tell us about yourself..."
                      className="w-full px-4 py-3 bg-slate-800/50 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 resize-none"
                      rows={4}
                    />
                  </div>

                  {saved && (
                    <div className="bg-emerald-500/10 border border-emerald-500/50 rounded-lg p-3 text-emerald-400 text-sm">
                      Profile updated successfully!
                    </div>
                  )}

                  <Button onClick={handleSave}>Save Changes</Button>
                </div>
              </Card>
            )}

            {activeTab === 'security' && (
              <Card>
                <h3 className="text-xl font-semibold text-white mb-6">Security Settings</h3>
                <div className="space-y-6">
                  <div>
                    <h4 className="text-white font-medium mb-4">Change Password</h4>
                    <div className="space-y-4">
                      <Input type="password" label="Current Password" />
                      <Input type="password" label="New Password" />
                      <Input type="password" label="Confirm New Password" />
                      <Button>Update Password</Button>
                    </div>
                  </div>

                  <div className="pt-6 border-t border-gray-700">
                    <h4 className="text-white font-medium mb-4">Two-Factor Authentication</h4>
                    <p className="text-gray-400 text-sm mb-4">
                      Add an extra layer of security to your account
                    </p>
                    <Button variant="ghost">Enable 2FA</Button>
                  </div>
                </div>
              </Card>
            )}

            {activeTab === 'preferences' && (
              <Card>
                <h3 className="text-xl font-semibold text-white mb-6">Preferences</h3>
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-3">Theme</label>
                    <div className="grid grid-cols-3 gap-4">
                      {['Light', 'Dark', 'Auto'].map((theme) => (
                        <button
                          key={theme}
                          className={`p-4 rounded-lg border-2 transition-all ${
                            theme === 'Dark'
                              ? 'border-indigo-500 bg-indigo-500/10'
                              : 'border-gray-700 hover:border-gray-600'
                          }`}
                        >
                          <span className="text-white font-medium">{theme}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-3">
                      Audio Quality
                    </label>
                    <select className="w-full px-4 py-3 bg-slate-800/50 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-indigo-500">
                      <option>High</option>
                      <option>Medium</option>
                      <option>Low</option>
                    </select>
                  </div>

                  <Button>Save Preferences</Button>
                </div>
              </Card>
            )}

            {activeTab === 'notifications' && (
              <Card>
                <h3 className="text-xl font-semibold text-white mb-6">Notification Settings</h3>
                <div className="space-y-4">
                  {[
                    { label: 'Email Notifications', description: 'Receive updates via email' },
                    { label: 'Report Completed', description: 'Get notified when analysis is complete' },
                    { label: 'Weekly Summary', description: 'Receive weekly activity summary' },
                    { label: 'Product Updates', description: 'News about new features and improvements' },
                  ].map((item, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-4 bg-slate-800/30 rounded-lg"
                    >
                      <div>
                        <p className="text-white font-medium">{item.label}</p>
                        <p className="text-gray-400 text-sm">{item.description}</p>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" defaultChecked className="sr-only peer" />
                        <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                      </label>
                    </div>
                  ))}
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
