import { ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
}

export function Card({ children, className = '', hover = false }: CardProps) {
  return (
    <div
      className={`bg-slate-800/40 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6 ${
        hover ? 'hover:bg-slate-800/60 hover:scale-105 hover:shadow-xl hover:shadow-indigo-500/10 transition-all duration-300 cursor-pointer' : ''
      } ${className}`}
    >
      {children}
    </div>
  );
}
