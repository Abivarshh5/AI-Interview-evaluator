import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Profile = {
  id: string;
  email: string;
  full_name: string;
  avatar_url: string | null;
  bio: string | null;
  created_at: string;
  updated_at: string;
};

export type EvaluationRole = {
  id: string;
  user_id: string | null;
  title: string;
  description: string;
  icon: string;
  color: string;
  criteria: Array<{
    name: string;
    description: string;
    weight: number;
  }>;
  keywords: string[];
  usage_count: number;
  is_default: boolean;
  created_at: string;
  updated_at: string;
};

export type Report = {
  id: string;
  user_id: string;
  role_id: string | null;
  title: string;
  file_type: string;
  file_url: string | null;
  transcript: string;
  summary: string;
  evaluation_score: number;
  evaluation_details: Record<string, any>;
  processing_status: 'pending' | 'processing' | 'completed' | 'failed';
  duration_seconds: number | null;
  created_at: string;
  updated_at: string;
};

export type UserPreferences = {
  user_id: string;
  theme: 'light' | 'dark' | 'auto';
  language: string;
  default_role_id: string | null;
  notifications_enabled: boolean;
  email_notifications: boolean;
  audio_quality: 'low' | 'medium' | 'high';
  updated_at: string;
};
