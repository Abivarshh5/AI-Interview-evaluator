-- AudioInsight Database Setup
-- Run this SQL in your Supabase SQL Editor to set up the database

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  full_name text DEFAULT '',
  avatar_url text,
  bio text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Create evaluation_roles table
CREATE TABLE IF NOT EXISTS evaluation_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text DEFAULT '',
  icon text DEFAULT 'briefcase',
  color text DEFAULT '#6366f1',
  criteria jsonb DEFAULT '[]'::jsonb,
  keywords text[] DEFAULT ARRAY[]::text[],
  usage_count integer DEFAULT 0,
  is_default boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE evaluation_roles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own roles"
  ON evaluation_roles FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id OR is_default = true);

CREATE POLICY "Users can insert own roles"
  ON evaluation_roles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id AND is_default = false);

CREATE POLICY "Users can update own roles"
  ON evaluation_roles FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id AND is_default = false)
  WITH CHECK (auth.uid() = user_id AND is_default = false);

CREATE POLICY "Users can delete own roles"
  ON evaluation_roles FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id AND is_default = false);

-- Create reports table
CREATE TABLE IF NOT EXISTS reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  role_id uuid REFERENCES evaluation_roles(id) ON DELETE SET NULL,
  title text NOT NULL,
  file_type text NOT NULL,
  file_url text,
  transcript text DEFAULT '',
  summary text DEFAULT '',
  evaluation_score numeric(5,2) DEFAULT 0,
  evaluation_details jsonb DEFAULT '{}'::jsonb,
  processing_status text DEFAULT 'pending',
  duration_seconds integer,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own reports"
  ON reports FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own reports"
  ON reports FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own reports"
  ON reports FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own reports"
  ON reports FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create user_preferences table
CREATE TABLE IF NOT EXISTS user_preferences (
  user_id uuid PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
  theme text DEFAULT 'dark',
  language text DEFAULT 'en',
  default_role_id uuid REFERENCES evaluation_roles(id) ON DELETE SET NULL,
  notifications_enabled boolean DEFAULT true,
  email_notifications boolean DEFAULT true,
  audio_quality text DEFAULT 'high',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE user_preferences ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own preferences"
  ON user_preferences FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own preferences"
  ON user_preferences FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own preferences"
  ON user_preferences FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_reports_user_id ON reports(user_id);
CREATE INDEX IF NOT EXISTS idx_reports_role_id ON reports(role_id);
CREATE INDEX IF NOT EXISTS idx_reports_created_at ON reports(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_roles_user_id ON evaluation_roles(user_id);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers
DROP TRIGGER IF EXISTS update_profiles_updated_at ON profiles;
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_roles_updated_at ON evaluation_roles;
CREATE TRIGGER update_roles_updated_at BEFORE UPDATE ON evaluation_roles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_reports_updated_at ON reports;
CREATE TRIGGER update_reports_updated_at BEFORE UPDATE ON reports
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_preferences_updated_at ON user_preferences;
CREATE TRIGGER update_preferences_updated_at BEFORE UPDATE ON user_preferences
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Insert default evaluation roles (these are visible to all users)
INSERT INTO evaluation_roles (title, description, icon, color, criteria, keywords, is_default, user_id) VALUES
(
  'Customer Service Representative',
  'Evaluates customer service interactions for professionalism, empathy, and problem resolution',
  'headset',
  '#6366f1',
  '[
    {"name": "Greeting & Introduction", "description": "Professional opening and identification", "weight": 15},
    {"name": "Active Listening", "description": "Demonstrates understanding of customer concerns", "weight": 20},
    {"name": "Empathy & Tone", "description": "Shows care and appropriate emotional response", "weight": 20},
    {"name": "Problem Resolution", "description": "Effectively addresses customer issues", "weight": 25},
    {"name": "Clear Communication", "description": "Explains solutions clearly and concisely", "weight": 15},
    {"name": "Professional Closing", "description": "Proper wrap-up and next steps", "weight": 5}
  ]'::jsonb,
  ARRAY['thank you', 'appreciate', 'understand', 'help', 'assist', 'resolve', 'sorry'],
  true,
  NULL
),
(
  'Sales Agent',
  'Evaluates sales calls for pitch quality, objection handling, and closing techniques',
  'trending-up',
  '#14b8a6',
  '[
    {"name": "Rapport Building", "description": "Establishes connection with prospect", "weight": 15},
    {"name": "Needs Discovery", "description": "Identifies customer pain points and needs", "weight": 20},
    {"name": "Value Proposition", "description": "Clearly articulates product benefits", "weight": 20},
    {"name": "Objection Handling", "description": "Addresses concerns effectively", "weight": 20},
    {"name": "Closing Technique", "description": "Attempts to close the sale", "weight": 15},
    {"name": "Follow-up Plan", "description": "Sets clear next steps", "weight": 10}
  ]'::jsonb,
  ARRAY['value', 'benefit', 'solution', 'ROI', 'investment', 'commitment', 'next steps'],
  true,
  NULL
),
(
  'Technical Support Specialist',
  'Evaluates technical support calls for accuracy, troubleshooting skills, and customer guidance',
  'wrench',
  '#f59e0b',
  '[
    {"name": "Issue Identification", "description": "Accurately diagnoses the problem", "weight": 20},
    {"name": "Technical Knowledge", "description": "Demonstrates expertise and accuracy", "weight": 25},
    {"name": "Step-by-Step Guidance", "description": "Provides clear instructions", "weight": 20},
    {"name": "Patience & Clarity", "description": "Explains technical concepts simply", "weight": 15},
    {"name": "Problem Resolution", "description": "Successfully resolves the issue", "weight": 15},
    {"name": "Documentation", "description": "Mentions ticket/reference numbers", "weight": 5}
  ]'::jsonb,
  ARRAY['troubleshoot', 'diagnose', 'verify', 'confirm', 'restart', 'update', 'configure', 'ticket'],
  true,
  NULL
)
ON CONFLICT DO NOTHING;
